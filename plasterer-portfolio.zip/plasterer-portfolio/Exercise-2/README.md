# Exercise-2

Start the exercise by opening **[this notebook](Exercise-2.ipynb)**.
